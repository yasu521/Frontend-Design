# News
~~~
      {
        "title": "Article 1",
        "description": "This is a short description for Article 1.",
        "image": "./content/image1.webp",
        "content": "./script1/script1-mobile.html",//mobile content
        "content2": "./script1/script1-desktop.html",//desktop content

        "//js": "",//change js mobile
        "//cssfile":"",//change css mobile
        
        "//js2": "",//change js desktop
        "//cssfile2":"",//change css desktop
      },
      {
        "title": "Article 2",
        "description": "This is a short description for Article 2.",
        "image": "./content/image2.webp",

        "content": "./script2/script1-mobile.html",//mobile content
        "content2": "./script2/script1-desktop.html",//desktop content

        "//js": "",//change js mobile
        "//cssfile":"",//change css mobile
        
        "//js2": "",//change js desktop
        "//cssfile2":"",//change css desktop
      },
~~~
